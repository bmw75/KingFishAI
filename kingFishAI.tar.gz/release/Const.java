
public class Const {
	public final static int BOARD_HEIGHT = 17;
	public final static int BOARD_WIDTH = 25;
	public final static String BOARD_FILE = "initboard.txt";

	// testing new things:
	public final static boolean ASTAR_TEST_CELL_PRIORITIES = true;
}
