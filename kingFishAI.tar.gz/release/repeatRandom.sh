#!/bin/bash
COUNTER=0
while [ $COUNTER -lt 20 ]; do
	let COUNTER=COUNTER+1
	echo Match number $COUNTER
	./runBasic.sh
	./whoWon.sh >> randomPlayerRecord.txt
	tail -n 1 game.log >> randomPlayerTimes.txt
done
