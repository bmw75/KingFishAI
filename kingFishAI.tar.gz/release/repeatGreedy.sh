#!/bin/bash
COUNTER=0
while [ $COUNTER -lt 20 ]; do
	let COUNTER=COUNTER+1
	echo Match number $COUNTER
	./runAwesome.sh
	./whoWon.sh >> greedyPlayerRecord.txt
	tail -n 1 game.log >> greedyPlayerTimes.txt
done
